---
name: Question
about: Please first ask on Gitter or StackOverflow before creating an issue
---

This issue tracker is not the place for questions.
If you want to ask how to do something, or to understand why
something isn't working the way you expect it to, please use Gitter [1] or Stack Overflow [2].

[1] https://gitter.im/junit-team/junit5
[2] https://stackoverflow.com/questions/tagged/junit5
